import React from 'react'

const Title = () => {
    return (
        <div className='title'>
            <div className='t-todo'>Todo</div>
            <div className='t-list'>list</div>
        </div>
    )
}

export default Title